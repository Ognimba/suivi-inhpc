# Suivi en temps réel – Enquête d'identification des points de vente (INHPC)

*Application réalisée par OGNIMBA Sadri – INS / DSE – financement HISWACA*

Application Streamlit connectée à KoboToolbox (kf.kobotoolbox.org).
Elle relit les données toutes les 15 minutes (réglable) et affiche :

| Partie | Contenu |
|---|---|
| **En-tête** | logos INS et HISWACA, crédit « Application réalisée par OGNIMBA Sadri » (barre latérale et pied de page) |
| **Indicateurs** | PV identifiés, fiches du jour (écart avec hier), agents actifs / 38, localités couvertes, fiches avec alerte, fiches approuvées |
| **📄 Rapport Word** | rapport de fin de collecte (~10 pages) : page de garde + synthèse nationale, une page par département, recommandations |
| 📈 Vue d'ensemble | PV par localité / superviseur, fiches par jour, cumul, tableau et graphique des types de PV (ordre du questionnaire) |
| 🏆 Localités | score de performance /100 sur 6 critères, tableau types de PV × localités |
| ✅ Validation | statut des fiches (approuvé, non approuvé, en attente, non vérifié) par localité, fiches non vérifiées après 24 h, détail par agent |
| 👥 Agents | agents sans fiche aujourd'hui, performance de chaque agent, tableau agent × jour |
| 🗺️ Carte | carte du Congo : points de vente ou synthèse par localité |
| ⚠️ Qualité | types d'alertes, % de fiches avec alerte par localité, liste à vérifier ; **dépassements de la règle des 3 PV** ; **envois tardifs, silences, heure de tablette suspecte, fiches rouvertes** (compteurs par agent et par localité, export Excel) |
| 🛒 Produits | catégories vendues, produits cochés par type de PV ; **règle des 3 PV par produit** (tableau + Excel « Synthèse » et une feuille par localité) |
| 📋 Données | base filtrée (Excel) et base Kobo complète (CSV) |
| 🔧 Diagnostic | question Kobo retenue pour chaque information, listes de produits détectées, seuils appliqués, contrôle des dates |

Seuils : durée trop courte < 5 min, trop longue > 150 min, GPS non fiable si précision > 30 m, validation attendue sous 24 h.

Filtres : localité, agent, type de PV, période (aujourd'hui, hier, 7 jours, personnalisée).

## Nouveaux contrôles

| Contrôle | Règle appliquée | Seuil (secrets) |
|---|---|---|
| Règle des 3 PV | un agent ne coche pas un même produit dans plus de 3 PV **distincts** ; les fiches en double d'un même PV (même nom à < 50 m, ou même téléphone + responsable) ne comptent qu'une fois | `QUOTA_PV_PRODUIT = 3` |
| Envoi tardif | date de `_submission_time` (heure serveur, convertie en UTC+1) postérieure au jour de `start` ; retard compté depuis minuit | – |
| Silence | aucun formulaire reçu depuis plus de 24 h (suspendu automatiquement si plus aucune fiche n'arrive : fin de collecte) | `SILENCE_H = 24` |
| Heure de tablette | écart > 2 h entre `end` et la réception le même jour, heure de tablette en avance sur le serveur, `start` dans le futur, ou tablette non réglée (année < 2020) | `ECART_HORLOGE_H = 2` |
| Fiche rouverte | `start` et `end` sur des jours différents avec plus de 3 h d'écart | `REOUVERTURE_H = 3` |

Ces alertes d'envoi sont suivies à part : elles ne modifient **pas** le score /100 ni le nombre de « fiches avec alerte ».
Les produits sont lus dans les questions à choix multiples du formulaire, sauf la question des catégories et
celles des sous-groupes / rayons. Le libellé est coupé avant « (Mode de présentation… ».

---

## 1. Récupérer la clé API Kobo
KoboToolbox → icône du compte (en haut à droite) → **Paramètres du compte** → **Sécurité** → **Clé API** → *Afficher* → copier.
L'identifiant du formulaire est déjà réglé : `abVbPCHqtiYSwKP8YAZ4QP` (celui de l'URL de votre projet).

## 2. Tester sur votre ordinateur (facultatif)
```bash
pip install -r requirements.txt
copy .streamlit\secrets.toml.exemple .streamlit\secrets.toml     # Windows
#   puis ouvrir secrets.toml et coller la clé API dans KOBO_TOKEN
streamlit run app.py
```
Le navigateur s'ouvre sur http://localhost:8501.

Seuils facultatifs à ajouter dans `secrets.toml` (valeurs par défaut ci-dessous) :
```toml
QUOTA_PV_PRODUIT = 3
SILENCE_H = 24
ECART_HORLOGE_H = 2
REOUVERTURE_H = 3
```

## 3. Déployer en ligne (gratuit) – Streamlit Community Cloud
1. Créez un compte sur **github.com**, puis un nouveau dépôt (ex. `suivi-inhpc`), de préférence **Private**.
2. Déposez-y les fichiers : `app.py`, `kobo_suivi.py`, `rapport.py`, `requirements.txt`, le dossier `assets` (logos) et `.streamlit/config.toml`
   (bouton *Add file → Upload files*). **Ne déposez jamais `secrets.toml`** (la clé API).
3. Allez sur **share.streamlit.io**, connectez-vous avec GitHub → **Create app** → choisissez le dépôt,
   la branche `main` et le fichier `app.py`.
4. Avant de lancer, ouvrez **Advanced settings → Secrets** et collez le contenu de
   `secrets.toml.exemple` avec votre vraie clé API (et un `MOT_DE_PASSE` si vous voulez protéger l'accès).
5. **Deploy**. Après 2–3 minutes vous obtenez un lien du type `https://suivi-inhpc.streamlit.app` :
   c'est ce lien que vous envoyez au Chef de service (avec le code d'accès si vous en avez mis un).

Pour modifier un réglage plus tard : sur share.streamlit.io → votre app → ⋮ → **Settings → Secrets**.
Après une mise à jour de `requirements.txt` (ajout de `matplotlib` pour les graphiques du rapport Word),
Streamlit Cloud réinstalle les paquets automatiquement ; sinon : ⋮ → **Reboot app**.

## 4. Bon à savoir
- **Mise à jour** : la page ouverte se rafraîchit seule toutes les `ACTUALISATION_MINUTES` minutes ;
  le bouton « Actualiser maintenant » force une relecture immédiate de Kobo.
  Une seule lecture Kobo est faite par intervalle, même si plusieurs personnes consultent l'application.
- **Mise en veille** : sur l'offre gratuite, une application sans visite pendant 12 heures se met en veille.
  La première personne qui ouvre le lien voit un bouton « Yes, get this app back up! » : un clic, et elle
  redémarre en moins d'une minute. Les données ne sont pas perdues (elles restent dans Kobo).
- **Sécurité** : la clé API reste dans les secrets Streamlit, jamais dans le code ni dans la page.
  Comme le lien est public par défaut, mettez un `MOT_DE_PASSE`, ou rendez l'app privée
  (Settings → Sharing) et invitez le Chef de service par son adresse e-mail.
- **Nom des agents** : le formulaire n'a pas de question « nom de l'enquêteur » ; l'application utilise alors
  le compte Kobo (`_submitted_by`). Si tous les agents utilisent le même compte, ajoutez une question
  « Nom de l'agent enquêteur » au formulaire (ou indiquez la bonne question dans `[COLONNES]`).
  C'est indispensable pour la règle des 3 PV, qui se contrôle **par agent**.
- **Département** : s'il n'y a pas de question « département » distincte de la localité, le rapport Word
  fait une page par localité.
- **Contrôle de la détection** : ouvrez une fois l'onglet 🔧 Diagnostic et vérifiez que chaque
  information pointe vers la bonne question.
